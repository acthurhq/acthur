module github.com/acthur/acthur

go 1.22

require (
	github.com/spf13/cobra  v1.8.0
	github.com/spf13/viper  v1.18.2
	github.com/fatih/color  v1.16.0
	gopkg.in/yaml.v3        v3.0.1
	github.com/charmbracelet/lipgloss v0.10.0
	github.com/charmbracelet/bubbletea v0.25.0
	github.com/charmbracelet/bubbles v0.18.0
)
